﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MemoryGame
{
    public partial class MemoryForm : Form
    {
        // game settings object
        private GameSettings _settings;

        public MemoryForm()
        {
            InitializeComponent();
            //create game settings object
            _settings = new GameSettings();
            //call method that will set controls
            SetControls();
            //call method that create cards
            GenerateCards();
        }

        //method that set initial form settings
        //it will be called during first run of the game
        //and when game will be restarted
        private void SetControls()
        {
            //calculate how many space is required for all cards
            //based on parameters stored in GameSettings object
            //thanks to that, you don't have to do it manually in Designer
            //calculate width and hight for panel with cards
            panelCards.Width = _settings.Side * _settings.Rows;
            panelCards.Height = _settings.Side * _settings.Cols;
            //panel is inside the form, so it has to be resized too
            //add few more pixels as a margin
            Width = panelCards.Width + 40;
            Height = panelCards.Height + 100;

            //set text in labels
            lblStartInfo.Text = $"Game begins in {_settings.DisplayTime}.";
            lblPointsValue.Text = _settings.CurrentPoints.ToString();
            lblTimeValue.Text = _settings.GameTime.ToString();
            //set visibility of label that count down
            //when game starts, it will be hidden
            lblStartInfo.Visible = true;
        }

        private void GenerateCards()
        {
            //get paths to files with images
            string[] memories = Directory.GetFiles(_settings.ImagesFolder);

            //set max amount of points player can get
            //this value is equals to number of images
            _settings.MaxPoints = memories.Length;

            //create list that store game cards
            var buttons = new List<MemoryCard>();

            //for each image create two cards
            foreach(string img in memories)
            {
                //create unique id for card
                Guid id = Guid.NewGuid();

                //create first card
                var b1 = new MemoryCard(id, _settings.LogoFile, img);
                //and add it to the list
                buttons.Add(b1);

                //create second card
                var b2 = new MemoryCard(id, _settings.LogoFile, img);
                buttons.Add(b2);
            }

            //now pseudo random number generator will be used
            //for placing cards on the panel randomly
            Random random = new Random();

            //clear panel from all cards
            //some cards can be inside because this method is used
            //when game is being restarted
            panelCards.Controls.Clear();

            //loop through all rows
            for (int x = 0; x < _settings.Rows; x++)
            {
                //in each row loop through each column
                //in this way 2D grid will be created with placed cards
                for(int y = 0; y < _settings.Cols; y++)
                {
                    //draw index of the next card in range from 0
                    //to amount of cards to place
                    var index = random.Next(0, buttons.Count);

                    //get card at given index from the list
                    var b = buttons[index];

                    //add variable for small margin - space between cards
                    int margin = 2;

                    //calculate x and y position to place a card on the panel
                    //x is calculated by multiplying current row by side length
                    //add margin at left and right side
                    //y is calculated by multiplying current column by side length
                    //add margin at the top and bottom
                    b.Location = new Point((x*_settings.Side) + (margin*x), (y*_settings.Side) + (margin*y));

                    //set card size
                    b.Width = _settings.Side;
                    b.Height = _settings.Side;

                    //card is visible when game starts
                    b.Show();

                    //add prepared card to the panel
                    panelCards.Controls.Add(b);

                    //at the end delete card, which cannot be added one more time, from the list
                    buttons.Remove(b);
                }
            }
        }
    }
}
